"""74suited, double-board pineapple for the Pittsburgh competition."""
import base64
import zlib
import random

import eval7
from poker_agent_sdk import Action, Agent as BaseAgent

RANKS = "23456789TJQKA"
DECK = [r + s for r in RANKS for s in "cdhs"]
CARD = {name: eval7.Card(name) for name in DECK}
INDEX = {name: i for i, name in enumerate(DECK)}
# Fixed, independent deck orders. Filtering out visible and discarded cards
# gives runouts without replacement. This table holds no gameplay history.
def build_orders():
    rng = random.Random(265801)
    return [rng.sample(DECK, 24) for _ in range(256)]

ORDERS = build_orders()


def board_equities(state, opponents):
    boards = state.variant["boards"]
    street = len(boards[0])
    holes = state.cards
    dead = set(holes) | set(boards[0]) | set(boards[1]) | set(state.variant.get("discarded", ()))
    public = [[CARD[c] for c in board] for board in boards]
    pairs = [[CARD[c] for j, c in enumerate(holes) if j != i] for i in range(3)] if len(holes) == 3 else [[CARD[c] for c in holes]]
    wins = [[0.0, 0.0] for _ in pairs]
    # Two actual opponents for multiway pots. Beyond that use a modest
    # additional multiway discount in the wagering policy.
    rivals = min(2, opponents)
    offset = (sum(INDEX[c] * 7 for c in holes) + sum(INDEX[c] for c in boards[0])) % 256
    trials = (48 if state.phase == "discard" else 24) if len(pairs) == 3 else 36
    missing = 5 - street
    for trial in range(trials):
        order = ORDERS[(offset + trial * 13) % 256]
        needed = 2 * missing + 3 * rivals
        sample = []
        for name in order:
            if name not in dead:
                sample.append(CARD[name])
                if len(sample) == needed:
                    break
        for side in range(2):
            board = public[side] + sample[side * missing:(side + 1) * missing]
            ranks = []
            for rival in range(rivals):
                ix = 2 * missing + rival * 3
                a, b, c = sample[ix:ix+3]
                ranking = eval7.evaluate(board + [a, b])
                # Approximate selection from three cards. An opponent cannot
                # independently retain the perfect pair for both boards.
                if (trial + rival + side) % 2 == 0:
                    ranking = max(ranking, eval7.evaluate(board + [a, c]), eval7.evaluate(board + [b, c]))
                ranks.append(ranking)
            strongest = max(ranks)
            for j, pair in enumerate(pairs):
                ours = eval7.evaluate(board + pair)
                if ours > strongest:
                    wins[j][side] += 1
                elif ours == strongest:
                    wins[j][side] += 1 / (1 + ranks.count(strongest))
    totals = [sum(w) / (2 * trials) for w in wins]
    best = max(range(len(pairs)), key=lambda i: totals[i])
    return best, totals[best], min(wins[best]) / trials


def raise_sized(state, target):
    legal = state.can("raise")
    if legal:
        return Action.raise_to(max(legal.min_amount, min(legal.max_amount, int(target))))
    return Action.check() if state.can("check") else Action.call()



# Simulated heads-up pot shares vs random, top-third and top-decile holdings.
PREFLOP_EQUITIES=zlib.decompress(base64.b85decode(b'c-rk<X>;S&mCfIorRKv_P0hsJlDJc(NO31X0K`I&AVGrrzVD<qQc|mTJMP%=mW&hIi6>LBXGxs4d;G5k@9}};K(0(z%4K&;?|eW>M^_JcM;GKf_dZa5=Rf=e0|NsC0|NsC0|NsC0|Vpr1RuV;{yM((HO60tMBY)4smQL558M9^i-UoIfq{X6fq{X6fr0UZK@9C|d_85xg1jXB?j6E!A$=D0Ya(c0krC1&6F*(Yq**H#N{3to)Q+;uj*idLCiPfk^cg5Pah(JM0|NsC0|NsC0|VnPK_E9B=LCs;{mUZg-X(kn+7H|)9ki@SHfTvlHjXvNU_JF94vo=}JsJj;5RTYKx&>?zubBy&Il}f6u!qF4;`xB7%ox_cTjg%Ao^^UpJvLdr0(A!5zYW2r<C{ESTD+cD4*nh|AqEBp1_lNO1_s6rLo9q}<Le`Luplq%>s>n$znKaEUr#}I4-9_DtVA}?GAOhG3#CKEXQYBQ)!GAJAJFO{VJqb|2!xXj0Us)a5zmLs<t+^>(c7yh9We2ceGcj-YV{D#YmWNOanczh0V5D-e@G%^<$Pu-;!YBvLJ}iTog_v%x1D~Ux7>K$1}u0@>v8($Wd<Cmlk{WyI>|r)Io1>PJ8gP`Q9TZ0dc`Wfzri;(1_lNO1_lNO#*Yp${Km%P6FXRtmjrR}2IV(UKHv@*uMv@+-3+~P5DJ6$;p;&j-r)j!T+j@CJ<^H^SZMD~jIi@TE6hWrn-H{@7~}eP%UfUHHn843k#NL9z*q7iq=OW)@P1RAuuD*}1c{yp5vYTh_il=`Cg9G8M8vt`Q-r+}-Q43H@#gz_-fs}YCXocyj09oPUi2)2Z%-oZ2^!QxBofs<5<yceU`de<nF5R)L3&EWe%x<JlQtRdCy}-MlnBc-wzodlM7lY8&J&;>GMDu42(vg~j?*T6d=lKtN3y<7a-0UadMsayj|1I~Qu_EdiJ!Z{z`(%3z`(%xYY-zgzFs1Cu^=z)>;H-N-Qhf-JFkARB5D6ln%?y5GZe0q=s|nl5JKi?5UlF?fB_|8*c?5)6APGEzBL|1E`TF!<*g_2E3E0(>c;tY#jsTj8lZpI{3&4(ygRC06-nSUC2gNWBD@px8<LbWMcJU8M?Lx!z29axKC~m;{O1~CzMXi;oCxhf9Z>#=^nN_Bn+ltg6woadLHZ;~ixe=XXq!R+WfaDt>1LOLhBReU;FC%j#<k+Jv}@bfPZKvs&v?+74DZS--AJU5ns^ESt{gU`p<*(L>PuP5Dus<1#-4!+XSMvy()+2fQK75~j8`aB56KbcbZ|FI+wv5soD^91iqF&gXNqBc4NJxT+Ua(l2bx^u4Lbg^2$+lFHNF7(!Zkhzls_-&D@Es7@OpSra(-w0y^{4>edcfRn+^sB1_lPkt?~66A1X$$uYYNOdiXC~(8LFTdO{F+PcCHKe!e~%HDaN3VBG&K_}<_{Ak&1facv@a?;VjaO7K%06Iwr7@cy*KY<yFVHQZX=c+VX%Y)piquh;s{3DP9`cjA;SMOmP)N4_;3xSI$VQj|R%2J3u9^I0i!x6N<v@veCD^D_?m@_Q))WKnvpPuQ3Y8Zu#H8v4*QrRhT%rQlA6v?#Dnk|vQ$%0z5xe3rK7pu^2l$miz6hG}A>;Uu|#b94*bO%r=E3G|V*dPp*4k%PMmVOlx&jOObV&Xx}D<Oowf0wVJiiZ4=TCA3$d?FG0mB2OcqUZC#g2t$dsmLi}MQl^ofMaFTO+c?u@*7n-zmL~4xC}Wm3!q<PKLndlhRDEc3mIU{2Ui*}c3bB_ZcZ!s$NP}4ySu|huMK4e678zp^?)a*5j<ue7(ol|Ci!5NOQKS`6lGtmomI?#@E>#}sTw?8yDw|s9RqfT?KlZo@=KiFqujD*#0IeRk^mUBKEj#?Fenw9_K$$mN2Ri;y4Jh-dslP*?G(hB&mRmng6O8<{q0hjp{6FG1aSRL$42)M6iQwk*+v5=f7UU(tdGE%;CJ8#w__|LTv28z7pXKo9=IIeTd?QI16R>|5C($ZPA{?UkjvR5Np`NnVKTU-#<><zT)?$`htDES(8z(I?bf$6$=_7k~;{lUQqCROVjPgw(9jTxpt@+TL*00Y+?HzXW85$k#=Ifd8-A#r}X~GVDx=HizwxoYoCd{k4M@Gv-nKGsVdpUZ)0C(W8>mjPsPX`S-%9@Wlpe<edFXv3y-0x%Q<~(<k^5035#vH65<q54XA2DTud#W0F2Kw{}%C`ck^2TDsnx|I&-KzOeTP|!Ya{FZl=viivJFBpkJYgwC56aM)RyAK=rmg3hjSoG`zJB?cCJd^7FTfcUqi9|g#-#wCZYwi3sDqY25p$l{D>CY<oE`df<Z2tNnt_IT)KZ6$Rn70$ncWI$sI%5O2i$0#MS0tx9aWX*Ee*&twg1D?V7w2@dt2W2)vc41B6}sqT!HyeVUZ5C=zfthm)ZRiyQ*&>zM60sBgRV9Qe&M^2UPcHan3TW>R_vLK!^2biL?bnl`*$shbv`TBHC}$jl1emYe#gnV0=4<ssT;TT4zm7$=Qv8@w*}#zZ<i?J#ekB`C0$)N7wD$aYQ}7Gh=l8&yRTZ_=_V!$NypqBHx>`I{v*080Xyytsj2^;@_EadVUH<es_M2pOEmX^w;wqyu$0_|E%r6iy{mR42<v7FKm6@c!Ju)g1jUIza>f7k|D6Nm9^({GZ9C6>$BZTj0p>+Lp-2bC*-Hr&ne51T`6c%D5okQ^b2;)e_5;a&X%vgy>*hL-<T$CnFv^UDg@F;2^iBsqeAXyp>8?asre~~61L_ejy&Xx^#0mkbl6RQxqA!rRCP;*tyx&vNNe>Cg)qwjV}>+lVI?F>q4j(^d{+sZa`ZugTIq(??G?hF4O`1m)inUVr1|<HZJEV3`<*5?X#ay8FsNykgFEL{!;W6x0=8_>Scuq*@D43%`|69NMOCsy+A8qLg^JdfuYf+XvCJM+pl&r9>0II6CDKyn4jNIAu?=mUDtEY)H}64bx!2Fv=fZmh%3Ol~wX>q#cjc%pPg+Wvudgs#Kb<~M^{FuCDy$b(v^qeEc9$t*J!)_8ppV?<ke95}#!AH6;9PA1DA^FS@fmA_v2}S@j|by)1f+9^wLIAB*FS2!!oHp|RXN*g2SSb0>OY*l95K{bYmEm?n@8`nRn}0Y%q`Z@;DG`i{y_8Z<~nU_a`txY5c+pCPJ?$fS-UFQ%D;DFNY8%U(TbYe33m_jJrUjSL&4f+je~@15C{4X;^@3R>F`-^<K^G#{`mWI>WsA&_cmf4Fn!UFbcp*JtfL-tw-Y`%FAvf|B%0iQS9Es-FpI8)=F&|By6izW8SKN##xSAj5chR>M=#;)!x07vw5y>flWOEJ85lxlEO}ABB|L-J!8qw3OW;aIvTwytW$!?=jpV>21>z?ubUmZA?}O9idM+QFrGGHpetA^~$Mce&zs#z~4=>9){#W-v<gc!pdj7Jg9{=@TT|dqe@E>2*uEkft@#5O}msNOGRXu-|SC1bpGvCRt&c2QJk0iXv#K5@a;K|K8O5XDL7=IZl&?j{&@RP}vD0;t>qRwn&qi2D4VxjbYA!N-^jvNJ)$<r>)7wlz1)-2;LMZt=qpsoK^Lt5F|^H9IV{rYs!tVCUT=#O$*z7-<Q3~9@At`dCWyQt|_iaPV8y-2&toE!QDm*(re9bvQ1@7)4Dm5?P9-Y-CXN+i;!5H{rrTZwU(VFp%tkLH`41=3N8dMYr!rs<rISW01QmGw7Rz^{%Vo^wrNo7c>ld~^EsO2DM362VVmEKx4aeC_AM<~(7pz<&Lz$^rBw?S-(p7<JTPN4~1*rpj9;ELBEzPk?Xnh_AD*O2pRUJ#DCDOF--Y7Ux_loBUiVub-YJ(o~@=Rp{tzn%}JRo+4pV?R*t>qU+keg(_pOM9j6Qvl%_u&bKygs#B_eceJ2iYiaq`W*tr1(h=NU0Yr8Mt?w+lT8y<9^Q?SmSL;XjIOqNH=JoSI?bW^CD~wHb-!0J%^8xwgX3SfoEe+1ug8LIX0@A0&>^B%oTX1%H7qpWof0}}~8MU@!j-D8RbxU+#4|!*YwRc4KaOKk_%~$fSK5H9E-r>rJCXp{5O1_?;^3I6}&O4S7KZ-k^bv8TvpAG##x^7L**-(AD6oU1KfacSwHfQf70;7a~o9~IC7Jtx<`+HIl>VS0X@*tyBxkd>v&Nzwqk?P!I2mN?plnMiTE}?NIN#8JjI8Lel9gH*4^qfkE<G5>_4$RYFoOvd^;*WBHspOt1ffEHVvrK5szrWb{`VUWqA56E7aM+fDy#$!iKn`hjiEu~s^`*cN&TA-BNC!F6SNVj0m?EG)XkPtHq$_wPGBt+!Pqq9RC5d6eugW-;!S01wI-=D#f}^-!Jx)_#<YO6)GZx*GRA`<JuM|7UqWD>coTq$8O6XJp<DY7Jo@G2onaD|=I?4g&IFEKgoR`>NKi*Ure)FXNz3cYdXD90Mvu8^k|Jl#Z;PG6?|L)lt{H=vP{^#fLs2}IIZ=b>6T6{NuE&j8&kJaPnKRda0oq+${+j{;pc>SM0o9W|!4#xlVnLhsGHy3!(j`7+dPHy^5DHiXEdTE~(wr43<fd=nr1<tGa(1Y~W|G6vh`1A0u`Gv4OAN7=>1Fc5UdY~Bf=BWeqSY?5)uWIZ3Di^46n{|GZzrFh(^2B~A>Z$VJeZ0b<eoC437pa3Xqw3~``UF>eL!io(vlb(oP|1e2u2YxCy)8Wl@tg1K%c^dCsLp~+Yw+kkt+MV?<e<tN*7*?R(R!>ZgsY6ZE(Ds8sj(hy@f@f#2X!&f7K3mZjPxHRsHw1dPGp|6-yGdYN11ll88@tZXnvfuS13m{de{<H`G)S(8h2Qyoi)MNfeN<;E#FvYD|*lt{OuUjO+<V@=5MQ(O7N}xRA1{e_E^tpW|NcWxz|t63T3Y`&ecAImgYknyt_(SDvYBA`=o6F<za*MG$^~8TAfwDHFl_(4tFbRZ*$Im9QH}$K20}gmvi;v-hRvrZKlR2ynX&)Ah?FGb2?0;_5VQfKPYeNPLHau?)_fl+^v|e4J#p?IJ)mT@laDuA@Q&scWviME9q@B_MYG#Kwm%7`q90VI)b|wI~>Z;Z^n_%6Ui|Y+{1)#1Rd){Mz51o(W5&3k?OP3K>2kad7SX6{&XUFr_f2w(&)TLa`3IKz4y=h2S2)Qo%mrd=^sO9I@bJYKN;-DeZ3?xf(~@7&3Bv)t9RTW6`rKPojB3_<}6L98jfUQk^#(A%O5ptEP19`;s}l~R|1+pCFaS)X@)#e2<R)3|2<KHs#Zq|d8z>BEQhY=R3$T>MS)tD0JA6&D}GUAK3K#yzJBq;_3L|5V4%=L1^Di1jzs#%#6Sv;Gm&wcfMo}Couh1Im<*{uooB$)1TzKs=t(}RN;Jzcb2#5)1;rnwL(^nnp68Eqkk6y162^J*C_^0OBS$%)^GOjs#c*6<kCpIgo;oc6epx`*b5deX3ZX@jT2=tRD5G)CD&%Q_Jg=}94e&h0vcV(1%6;;5vYz87PrBc`Zi5Ut&PIoM7V5@o*C~!O#4H<`!x^3AP+rZ8%rr|*v)pkGD0ZyPcUFi`Gaz`r;x&C1dG;tro#vt^Wl-TcE24SLOHoy^vm$d^VxbOboJCnUDNrX>Zdm}zFKZ}%QDaWa)M+((Q3dfAb#$HQO?FXb&YFqKCSdM$B#jrBb?#m}dD%{>-(L1m9^UIFe*fWv_1ypcgZqEAZeRT7BQV0Rp6U26fAhY2{KLoZ=;J>H@n8P>Lw)?GzXU)1<O6*?WWM<1eSJLSzr4o($7dgd^M3N)wd?r^j-%(l`0V}fJ}<n^KV0L#gd=?M>vwhh=O4X|P0$bFv$&0yFN%j)ke5V}_Y`9OdYpj139YXh@u0HxS$QQ9_v^3u1>RRy{gDK9OQ7{eOA6I_Z%qt!65t)Jz3w|m<n}Z5o%q46)vdv~t1+UL1iE#S=zYHx4>bgDGevf#2wc`O+PXK`RDYBp2e4l-NTKyrH^ua}{<qywa@}~{>cU}F3bhkqm`-TD+7SKVVcSHw4LeZ1O~1ygn$S)nGKBr9wQj=<)fK@yc`SqYaVDY(7})ODAImrAbMsm;PdyRp!;VrfgVw7(ne2$3rW6=vqF}izqde@3u1><&O$NtseLL3rPy;zQl6>7vWSWM3E3HpAQ^Kkh9VLU4ECp?a#>>P~-qcCX^RM6QXGik1<K6-6@D8+n$V0{7ll+|&F-ZY_oJM|glsxPwJl&*k3Z3I5qxD0x>@evWq{H(J3BT2RXwp5A+>^9to`=3e^I4M|sXEh1Hgc2)@uzEFkPSYpY&~D!dUflfed(|z`$kzXuZe=@J5UY>vPTtj0{fC<&3{cZ#2}@L>>X!epR~YeI;iIBaFhwmiXgA%xuE7F=t<f;R)Q;L?K@_<z$|?*D-b7zFtiUSZ|7C^sOUc~_*DZ1{6Ynt_qgnPHrT9}-Whs+blpa(RnODYBJ|^B<ge#>W}<{fS@Ng^eAB#)eCTnVpJoH&0yD2bzgb4}I<4`uJaLpIPAfFDMQEJUil}DVsj5#2D7>hnan4GrZz4{s^hp`~z0RvBepx3MrNE-WUBJl8Ms&qr)uYQs=%U5kYePTP*5doz2g}XA@sAe#52o9+L{EzJ3@Ua~=QJHym6=u9lbQ(l#@Z)FW@YB6%pJkVMI)y9Xz{qh9GAIe9r(~i6OFTM@h4^Kq|7YZAo8>&uK3Fae^!eu>-<Fv#9wyfNS`*hY;u=P?xF=oxah|;U&&pz>5GnV)dN>@Z-B1nq8GjF^H;s(!wHDIKSp~V9u3l;KJBgNxc&9_g?XKwHTjb|IPY;Mg<fYm{7EBrTo+GT;7ZOqXugY1Qss~8;sPpguJOyZbkY=#Tk&NV#4mejoXa+M))Gz|vGX>V>BRu?%W?Kxm8c~w`hdC8_=~=H-eE6$iOYTh@Dt?6FUPTqVeI}$dN2j!KbR{kUj6oJ6n{8X9?!vZ4Ugt1{=t}iI7>Y|DnC92Pd7Y0LGcgg^6x*qTF?FWA3px8bvx=LPCEJ19ysq}l0*5{lTSL*aa+FVWZ><9&U@OH&U(p3FMZhq*MDz>_+>AlYPA?-?~QVBzKFjX%9n%mc|UbIRA4@2SN#2P;c_6|A1e1Ic{qJE->X^nawJ`i<oh!a|L{1EbT~;rn97eP>Bo?HbcA^I+Xu(FhsVVyOYr>2({uE6$<syt(Lxoi_0|F~PcISw=Dqf#i~5s`#+wg72EKKL>Pv4v9sk#t|F+iTKfn0=|JCjJ^FOJ_KYjgY9slQVUO@gU9skYOe^ifOJ^$}(@z25WTKw~Gz{t;Ee041zocGT!zShUX5uU$zuH(Oc0j}rkZ@<-#^FOQcztQvGzF1$?|K-6Mzy3yl-mhM)#?kYC{N~&5)a`!($(~wr'))
def preflop_key(cards):
    # Sort descending by rank. Among tied ranks maximize the suit-match bits.
    a,b,c=sorted((INDEX[x] for x in cards),reverse=True)
    ra,rb,rc=a//4,b//4,c//4
    ab,ac,bc=a%4==b%4,a%4==c%4,b%4==c%4
    if ra==rb and bc>ac:
        ac,bc=bc,ac
    if rb==rc and ac>ab:
        ab,ac=ac,ab
    return (((ra*13+rb)*13+rc)*8)+4*ab+2*ac+bc
def eligible_pot(state, me):
    # Chips bet above our entire stack for this street cannot be won by us.
    cap = me.bet + me.stack
    return max(1, state.pot - sum(max(0, s.bet - cap) for s in state.seats))

def facing_large_raise(state, me, cost, bb, foes, high):
    i = preflop_key(state.cards)*3
    random_eq, opening_eq, premium_eq = (x/250.0 for x in PREFLOP_EQUITIES[i:i+3])
    raises = sum(e.kind == "raise" for e in state.history)
    short = (me.stack + me.bet < 12*bb)
    if raises >= 2:
        equity = .8*premium_eq + .2*opening_eq
    elif short or state.players_remaining <= 3:
        equity = .45*random_eq + .55*opening_eq
    else:
        equity = .45*opening_eq + .55*premium_eq
    committed = sum(s.bet >= min(high,me.bet+cost)*.8 or s.status=="all_in" for s in foes)
    equity *= .80**max(0,committed-1)
    pot = eligible_pot(state,me)
    price = cost/(pot+cost)
    risk = .03 + .055*min(1,cost/max(1,me.stack))
    paid = sum(p > 0 for p in state.config.payouts)
    if state.players_remaining==paid+1 and cost>me.stack*.35:
        risk += .06
    if equity < price + risk:
        return Action.fold()
    if equity > .63 and me.stack>cost and state.can("raise"):
        return raise_sized(state,me.stack+me.bet if high*3>=me.stack*.65 else high*3)
    return Action.call()


# Field showdown frequencies from the released Practice 2 histories. This bounded
# predictor only uses cards and betting actions visible at decision time.
from itertools import combinations
from math import log1p
import json
RIVER_BASE, RIVER_TREES = json.loads(zlib.decompress(base64.b85decode(b'c-ozPTbAUwuIq%VYw1Nj#<JJ>JoBHz1!PO2({S!Sx8kciGb6$_1%f0<{wMs+HODZ9g*Z~LDV0C}`OkmipYXTiCwRp_cqROI_!Iu;&-_VCfv@~0{b_&x34dem5x*G6{*4;uzw{^nDg2ETQ%?Ae`3vECGraJVka8XaAN(icN99lcYZim$SpL|bI^VsgWTn?3{y64bQ?Wk(_{aN3D*=Bwf5h*fETrBo{lRa?`76y*Dc$z_;vN`Zf5xA9zsV@6#hArMht|>vqy6}3{v_01iZ$`2VypwV`F!6t`h5MtXC(fQh=&nc==)aU8_d@q+>zM$ZY}o`N-6tG)!HLo_&Kh&@>lRA`@moR_}<r-i<XP{)_s&*THZggQTPvUiLX2O)$rqDcwXXNM-Oe(`hMHkQjEC5`IGB<`h5LK@lTr1rI#9Nh~@pZFiE^?i0`+}1%K8%e}W%f_BxFc-}Gg#*X_Yi5^RbVWw;BuUv~#z<ZmA~V7}#;E1p6%Qx<2jgi)fjxH_V>`nI?Vi{j@7n0CTN&G+SR#L-%TRp1=;`5v{Dgf~g*lT$0D*$|%`a)3pI%i?GwMgzXA9B&pXj9A+6=&-D4%2M$cI2-5FddQZi<=mDUdKnpyt{hXvA?NFus?k*Q$oqo#E!n0TN~<^&;^~K6d(R=s3x;I^wDyl`ohP>(V~wf6pj#C0i!a`D7FHE&!ex46&7H4wjMW-`t9Ee)Vr}umSaCK+3d0-gH@M<0@Jbt8Bff3QwH=s>^N(#=Yc!tqI;t|77I94OD<ZlU7)tE;E(=|O%)BOL9cDG+PATi)2@16xQy;i1wYCGU1!o9<er}Yd>*dfjc3OW|pN(7GtYv{yd`J@y#R(~NV&_La$N4%o3lojNTyyX`U-j55pDs>X{sms)%epm%Sh#5oha@U|?G|!v&SclyE|X2TV?9;{ulVA03c_N0F}v@^ydEojIe4vY@Mv^lu^oS0U&o&p2-GO8d4ny>8@$=TeAzNsl8J&dc3hYd-|;#II|%KiDT5tw>G6iLX|Q-YBc{3y7IXoYC;t}4(Mnf<0qbmltM&^UC?n#!n{%sUqG~+`8$o&iX!5Xt#x#6}c<=^a(ppt8218EW{n3jKz-n3o?v~#S77wz8`)*#>mTCoLI6lxu#_dt2Wk9Etq*n>8=HPhDn-So%@i?N1_idml@AsXY&3en_SY2<he7ugy;(DsR0c`?LP1chzSze-58y}1y{LTm>_(U3GQG!ecI}C?>+iV4ZgOy4a3OJZ|SJ)kRE710^+gxA|bUrsHfNKC3fn$Bc`{D$|>)b+7RtMreK!OzsEqK==VKS7;^SX@=K#Q00AP|hnLTYa}37Iz%{Ky75`gGg`hz7c7!H&%VSpl0y%Z+7`-43>-=pz0;;}OdvkzjVM9YDi>;Z<qLH~+O1TbG_4u5#c<!sr6rxVz?FYs9P2j;GDx9+yP7a}FB(IbQQ1CjO5ImsWDEil~A~rSL)?nq^495fjjz3Ll<jZ?G45xBt!xaJ+iQZ8|3p1R(OY4K{(mfsRTNi-4_KSyt%?@C~wbRuQLHlEzdsY&J^E0#unDquV~e-`1Xhp9YkZE*}gR@crf#7nhwD6%idK1vd$RH>!%cU`{=B7n{Iw^EFw)W$!TN4x4hU07oA$2ePH`U3zo|zrNiDSw<x~=mLwy;mDH7)(-ekexo%w=vv-5xosBT5O$l=FE*P~!f76+Y!)X8_eRBR;K0BsVY4~HyOX~E-@>k&7#M8KstUVq*It3K{to69{FWQ1@tnaPYL-TAaHm;%vPSnj)Q?~X2vY8VSTorQ;(%Z<Zr`vmd=mqvCt#bB7~qg2ZjSP6@rG!=k{QE0{`;n~jIBy)MWFOD+6-RSqvI=ezDer0(O$=y!Ek8ur1#iVP>(lmrN#Iieu1G4gcYV3M*;8-8Ghj)hGOwx|2F5iP#Tm(#K%`EXaLo!0$Mm|ggO5XXbs04-(wqX1x({Hx$x^Eyob$#T++wO@C(3W>j_Js1!aki?<SmN$DL{#(m=yPt-r9@MD9A8i(+B{5P-jon+yR=1D&3H@NgudD_Q~OnHbfHFJ%CC%fG;E#jWcrk$3ra-pcF^7LeCda#Xfd5a8iawlF4_h81QgEU7Hqb}15N;j)6mIuMA&e+OlOc^wXKyrF-iEMkAqLq$noIn9dl|3Lm=L)mM_6^5DI*!FrwP(SQ-KGw@Az_xA=3*L-xUk)s^E7f2NW#JE##c|V^hxKff<qa-L!WoDt9+|`}I)ah9%jCjXz%>t(#pi;eNhV7I#$-~InN~d8Ux~p0pOf)8D0{6kg=BzKPo4YBZ<!s01*JeF<xt(?WQ`7C@#Zi(PaNjEbZ4(HV0`(m4mfk)+0-d(cpSaH@8rf;Q0)O?IaIO$kQGcNrV9?}ZE+f2D_kf*r${^QIc3FTLxZ&zA9%GvsNvW3f!D*-Hjga;NIa#(V-fE2--1^h_f&?4R|HQaWd{dg2MEJ~>kD2Z@%J70UVjYEH!P{xsRJ)==4CUT+II#Qu0F{8EG`ASILTxxZk~naBCeSzEhpkCK&Y~!OZ?x&6z&SPQsOhc>FJ%`bx{@^ZLTWH!Z8Q_cF8)ewh+eSNPz~l6J;69KSX6;xCOn+5&{ftW_w@h(~YG#K9O0JV-Ov2`#4aFM+){Cg3Q~(5|Yjb)5#YV2jiZ?!onk!MWct$ep=@v!Lgk``4UX@qy-S^#Wtg?J5Y+`zXxp@%Oi5wj1`a7a77={`}BX(!y}jhtM~}AfcZCndeG4oWWjmEdrQbk$>1QQ`^LE+b%^w2yparq!mPVY6o0?c-!4OCTDa#?g!?}B3g^a@q{2hQv_<C0@C<;}3MpY<aNz>eVp|zBlBhJAh}<?=wK4FO)ER>7VJ=Ol$3_ay9GOie0Y7kx#{zT7O~EPRktWeJ!z|`qP|m;n?)*yz=U&eLfw#+E0k$x#J30G+%w@2!Ur>ZNbh-&x)TEQfL2LESuv{3mynd&rZMEqV!+;sdL=a$Yur9RBoVCX`%H{R*6{o`Wj^?j+TI*y;_-(`!5=U@G0o1Z`+eg<Gwm5L{BMG)(x1GUfw_a|xFio-JS>`Z_z-4D-28iOjD2KJ%5ln<jBT0JO-l@KS3PP5V|MwpiuH*Vst2fMF$zxh5xWP8jgj<|V!F*?ET1`P}XT{FfUKtMJHH5?8TzNriX7G6PcU2t-ELcA3^4=(LvGq<|U7mS)`aF~DCao-z)U>Es;OO0}1O{t$d2El52cJ@rr8S(r)Fpa%3IL*W_$#X14nK9;XUfvy<1w@Rm9@iXx@dG|Az;@A#wrms_0sNx_A<^p_L^a(^coqz*;P>saW#GKx5o$kvOE#nx5o!TE3r$H2MLSabU=r99jd&*EK;jJ+Hbu1ta(17ryth2qNixBxMG=0tJXV)!Kp~$1hHjI<F6Y)8_Xxypz{GRgxcj3BD1XRL{B(-F!pk^0r=2)%G86$ZO-~_Vfy(QJPj+uyh4BlAgUUq+yQ)Md?eL6aB8^XRlIN24)_x;$X4n4q6}7zhja%}IMJ|>{v{B&7%mtb16aWrMv6JuhrzSPs3=1Ov2hXXs}{g?VM#D!cm9sGRvw$Ao&wGnX}tQ#S+r28)<o{wAF=*QJ^%Ff_@9?%U>R#7+py7Gs87mvoIOmFbq_oAH8uJXJGL4V)i^RA4;=oA$On&r*>|LmuLcyCCdI^4f8UIM?qXybrUU(aK~X1#xxR0{ka3;rXjBrZsv(SlU?)EkF@7u>V~k>uA(EW7qPAIea9A*AZI;%%P&FkG{E!u@GGHl5WrpCQf6qw;-i5d_9{p*dEt1o9S(GKXNgf>w3_)e101SArG5!B}`_d7cGG^NueVgLJ?d;(RIykQk(3w<g;aC~PXMm3r-Ln$aYm<Kr;~#kF5)ubE?#-mGZ*62dZ3j?erp-;A3f>OZ&eZ!>5ceLA!NB42HBJac@mC+Wi9WpkGPn_gD?-DKTsgw+{Sz*#^db)|n8D=7%D1#SQkBm=Q~BUB$tQ9uB)v86vj*2SaK?P#l&IE_CEf;1$W;n>ECc0_$ZFRu7Ac)K8BR;*2^mp$nNKxx>!_jhN7nSxAdUm27I^0Bci@!iBAV6jz=@@}DC@02Lb$@1-rOC&xNh$L44YU!ktPT<L#U-`UWE%-VTu<5PQE%=c~M9Nu3DOAvea=!Ctj(2O8nAs^0+aX3E`8}M;z3~aq;**c);bIL)kgfh)+qT;$+-W>cHf+66SgxD$f}PbLjggBTrh|9v+@a2#KHIoQQ6U^6>n;ROC6zfas?16QGq!Z2vVqdg-R8#Zp<FFRSZJBIrzfh5tYh@-70E8+=oP$);j&x#<GX&_Q#o%7a!qU87Eq0tZ5Rr$>n-xoB|~J$DO917`*ebc%u#T<>rR;WZ0lB8hW?CS!^Id^Y?Ui1=8s(*?g;6HO6T)0kq29$b2<&42xN@V66!ftC+ZSZr;mH%?Q7+<ZJXU(Urx#*uk!_{Cc>msOmlf>gqxYC$#-U&3#p=1-<d!DU(s`QLESa%Hf03jl6yNzBHaQ%;V^RMaM;Jb_DMH3NS*4m_U|I3dc!2WFXE$J@1cb@yg)a6%fr;Hcw@soHI+cY%~T-_d<l&vt1v6(*&sR2UgJ_B%=05JmO0k^DLpaiZkBJD^J}k|^7YxNaS}8LI}41zuu^iJO;+;C>lnXQBLCDJMLozVg#~#=`iMn9IpHWk3QrRFRc>0A7*mvKZ@BBfJBoK)-K879@bI)g&j2lur$XHmxG!Dvx-6!sk`JKlpjw^JR}rpTN}5Bg{)cv6v?yCAO}G&tUn<oLF?KebYE)CD#0{$Ru_|j9X>EOeI0@<A?!pKzPPCeB%5N!n4j{MFN^+cLQI>p-h|cEFbWK&&VQoOOJ%o!cAtsb8`hG3zs0!;bx_9OUg&#X>p%r4U^@gyZW@K?gmYEi$pCh!%>%-6UqsDcNwg~^h0upi7!qCz9(_VEDNb>7)?rGD|5?|9fLLnm1SaPzdpo!Ix4!ae48cA3cTY`d_yRl7|?E>+3Ay=qe~t4q#v4zcSxz4lvP?OAGQZqK2p$$C%A*;lKT6k&@3-sk`W2WC<{j@4XJugh?0U!AHRbkrgeI={#8)Az8v+F?KnYjk^(>I6QYT!GaJ&Ja65N-=q0?PvRctc@YC$8?<Wjfkr59mynsC_4=X5Q0)T8pR~~wgGX8FTGfP>UXKkXgq^pD7I&|g<fnQJUp^EO4p!cU!m)TG}Lip!!?mn&zCnBGy2w#eFVwWzRYLjEFQ*=<07LrnEXdfZsOsO73n_8lBf+Hr1aL+#4R%%ks5@A->JY!zT{+$b@DdC!iE<OMPLvI_u6NOtX4d>`tBjp#9IoiUj&^g*zhWpXm(<id=nyN?*EKd(wf@>+RopBP%=sZ33n^n?9#D611mEkuab-wS}qi}E>K1%>mdo9K@O}h2j#3OaD6|vhD-cFOfUB|ojIg96~_6hb0Cq2eH*}0508RL`Y>Cy?_Nfg^l-e3R1a}H5mTWxo}KcelebZWdhoz`M0;;p;=XQ}H(lhHe<Y|B;3-T;X;7D+sD7=q}uxr#+>c+u(*_8$b7Aae~RHvlHsLAWvZil0xFv*FkMk<VkAb3K-b5Txp!q(I$zl!U^FB>D?em1e^k=}al%{SSKb@V$G83;UzWNA(mRc=Ia7JktmBB;U^Embg3$M2mUCHvsr_g}pN45$ZbyzC(7VlSlqZ*KtM?uS2^!_N6ApJ6G=$E7Pl$(+5NU+*~I~ab4`;qj+Dy7>bta6ecOVxWcWwW5FktI~{bNgPlxbn@)2@u)|h&cV4B6Lb+eu+45G@Ueug@otJIRFbS~ELfP@^a5*FB>H-{7`k-A-`1Qy%Uv_ynL6*D}QLm1O*$yl%ez1uC5aLfdJWOPjmL@4Jup7zP0kRls{A)*USLj@|+z$9T8?{vs&H(+ku?r7YgA;YeL6-OySW@7L_(DcghQ}afP)z33s^NeYkk%eJdPpbZs7KTPvY&L<m~i!Jwtgva3iTEX^lg`R2|+<KYn6IA%c-i=;7nl--|I9Bs3{$y8KzFKsouV6nAh>{G(VYKU_7Zycq!WGE@<qtG7Fp7kO|0&gbGzpE4XE{xH>urP>L_-{d-4#pbiB$*FIbF>By;SlgT06HLxXJ>*=#y*qOqzOE!za6w5oOMZ3JzY!<uBWx`@hmCQA<1{)sEcyr4L?jMKl#Aos5qe7Y4{atPmPq=RAhRQJ~N~pZ(MognM51;Bj;$+aCHsnMHCIfY*2IyU4d}G?NNNOh8jj1sNI6Jf#XU5QFf#<(*43Yws8JG$Vgt#P_Hps*>p$EztWmXjc9d+`3A%R}3jd#(9obqDzt=K)-<a*van^_Tvq@)E&d}>;jPJMiFg2QsbdfHZ5%WMskMl^Wdt7O}?c5{_=gx)c-jJB;4!7!=34ynTY1L3nb(*%;`7}H01itA09LIY3DJ@nH7ZQI205c=IR_^co8&?m)b`^D}XJGweN30%Re(qVsd9qoevPCU>`h3P}@?7>|>T4rkOx(rQbnh=ZkAZscWv2|Q#`lwMp(es&4q5?j*dV-!-XF(uu{kuh+#gk*HmpR1~_{<tpmS&1;A6e@m5hJ7^+lxWHaEim>QW;N}Jm#XCmwbc*?DH&Ay-GEwH;F-}6<L?!fClxjQYkHU{jf3)bsjsRGr%Ij_goPZuwVL0WIT09yEm!wlAA98Pg(LoQ)8m8M9E{uoS&ki-9mWoGT{jX7R_)w-x&xLctrE_hRed=nVG&bjXt1_I^ek_KQNAu){&8}Jg?%L&+7Wpcx>lh=rZmg^atI{lwMcUpfl-<R^wLY<OSOd4Yn8KFJv?0Z{M(d>(9$asToW&mUC`fE__7?pRm1*$1`-BO65C921u@*-+}A#@S(H3K2$I?JEO+U(0;o1#MY-I+d`<#_=qZESZen#wuwjHn^xn|L2JWexnwxQx~iScId@}IObt?=K!HM2XTAeXuc;mzHFw*>k1TwgsA;QJ2N&T)No%&zwo1<Zh#G&&;A4}NI&{lhv0m7%N>+Dl6O=nWx+Ctpd%JcvH#eEsM?@TS%l+g6I?!e*CEdC2pHUD;BiWr!?9X~orpRa2idJrWRe}nx2%u85Z(~R%k$F_z0?9cNt4MIO<sJDn7-JtM5P5~<oCH#}$xzhSl00z$vQ^Xcj{5?tN<{x~J1tlJ-0>{{!|#M;-S&5vNS7UqQg`@0jrN*}mN%=kSab2$zWCNotK;`WkRosvAcM}zF#Fql$I6QNZUfBJ;m0gNBik%si!%sHv7Y;hcor$NQkVMis%E8I$vC~njq_2=*t_yInQ}KBg)lvL=BfZ;XlMP7$S*koZkoyXHR3MRk5;4H!<yu=qOG=cY49DRxzyf)>wYK0DNl=bOP=qOHJnM;BGqzn4lhbyfqK<4Cmhu*e*y>G;_yMwj<_{0=B0weW6sitWh*I}(~)OJIH7K}(QFF|)%9+}HyLlG{kc_MjCpiG#CF3h<2NQ%*7KO}S`ZZ0yE=J&=|r`cR*lfYhj!_9BHU+4vx??Z>rrn8_0&J^+ByEadv))-b`G9vOqWa9(ZFZO;;F$-eEn-TjP440B!Umk+f$+q%Od(fY!y`nZ0v+2zjAsA`mQeh!!7IV<J9VIAShU?$?6+|k*r(k*u^&!i_2cel;@20FRGMNaFT8~ozKa@wgLaAN*OtiGrKT;PAD6B;^~D!trXLC53*O(A>)Xv)W`cFEvktVlG?i%cn>hdy-1q&w-!vOlU=BeKo-WM?>~*ApLr$#2+q<fK2&e)G1OF*+31j)oL@)2;^gqNjkX;%d}MoWO~0w(amy-5qSnpefk+3FSh;CO2A;t`@(B3=D|=L!HIb}j)Nm`nZaCkRliH{m3kNCZTqTpA+I+B?>iaWKVCG$Zf4cla>J)#`7X$s%`Ytbd@x1@m>KHoz$!ep#clcV_{B)a@_gOXyg38-lwdwO%Rn0mPW<6xf$LYgQu%GLg*O>&eojweyh9V~bvN)K6Y%hmz9(P%Cv8?UwDb2N^6#=m6Xi>X+>Koe-trpAa<EfNN)xa-Ke-y_4E}=0~jO;jECK?l)M?OR<_>oD$LY&hjnw-D`0w|TGl{#<pGWa^7l-jY2=AF1FPNA410D%J_G_d5xVz*O2fDeMjHeW&?Vdz#DK*N%5T@S9VYAKMYuEhVlHHV{trP{jZa_e0#^Ba4dY#QBGt|3f%a~g)pb|2Ytc3e!<SxJm3SkRYHE_$Hy)}yR%^P?=3Ga|fEKc>~RVEPU5+^zZa#uXObNP?UG7^(Y?(E(pG5v*c#F>UPr8#tNdpV0}7%Iw66A2T>ALQt6`1YwMQ7b$-xHOrfZw$%oPi}LAQl7TZ3gp#;9HdA6&YHJ3Nns>`Sb%4IseNMsR$ECn$#yzF{#P&x|48jGR8E@g<N@_BP-sF%V9vzDxiDtTm`UJhBE6yCjsnu1vgqrk>MMTyM^LEzghAE&;a07Y{9Bx4|Md>-HL3k_I9vkEGV!EB<Y7tcm;Kuk$AsUWoHLv1!Av>oir7RgmLL~elPhgwyR=WF~rH9D)6uRH!i87p^>-B{LtINrJ;|Xv&XF3qc$>K3-Cjf-@5|(@iY#S+Y%HjUv$FpuhtK(-@`p$REw&FRG5*Kt3bM*EY+QF%E49MM}g^IAyPi<MD-5IwK$80}S&zxyoS@fus?Nk?2meQ{Q&I>=M`n&1|70xHus@*v~y1ueX|J-GQ)f;(ByCX-LI-v)Z|6xcUzzqROgC_^j_@1`A#^@{+guQ01`bl%Lh90RyZC7-bdeq%NBcsTfd(|~%gjv<-j=JFJ;-8bmfy{Q>GZ~FD81bl!D`U<9PdbR1Lw9u1y5%M%5A51s^_vGuP9UvQ|2(S`FH_si8AO*L=M>Ct#w6zyaK4K<9*k?O)aN;=991Jh7p*%-rfFAAQuolk9E}{s$IgyU7uv?s#)+x-p=rxfS4E0Yq6T+ztmA09i<iP}nJ7mLyN<*QLTBl>NkKV$b=F0`1~;42zt4GAmd{)oq+H$9Y3Do(r$4q6J@zT5Z{{nN#XhEQM@}WIGR53FXy16}c~(80C!|TP6p7|Kc?2shG3lIVnF8|mYtA!K!`7vyjwu>Fk2?~oYuyZ-(x}`^bWu>E7_^(@7#xqHFNfqj*|D4L43{x-N<;Z*Ord1@v1es9%j`NOV=r9oX(VQSp)(V>HN;a_mE^cksyC`0(?-ET)8*+o*QNf~rpv4PGjn$JxOm!P&^nzteY_qmC9WfPCeT(Il+BDexX89r6V>mTbXTwl43y8F!zhz%enHeeLTL&%m&%S+EvY|atk^V4$7-!S^lUr%Y52%?%K(3N40Yz)ZqBu0tex+qTq9MT<la4FKdUukhy3@6$xO7k#8FHfu{z{|c~lmEbVVfRl-VwfS9i%y1g715??_8Ct<_z&Gf$C}o>^U3e)~u;m)3*!=~TAm{C`a$;g-y<<})dAa*T0ONO&-5HAQIt88{kJcQ;ItPyCQt_P7?Yyo&0VsEf%^t+*Xg*YNRq<~I>NYU+74gpSe{IbpXv1Et}S6pXPJeuD14<-|H!vNNvIdGyI|3<XikO$vRf_G(=(q~Xl$thOhuf+n-BWi*u@-PE%)YJVwD+h5+_4~-IK{43^ou#A)D<eHu$XM6!hVvyKc*^uA=MFnX})Y!Py4t{cSqzzp?pEs&G&$;VI83(32x48;TTlvm$*Y9Z`7dn_(_>eTfRo{g3QN%eT={X+kV|F(zv?lq!g@JI2ZuID_23kjWj_O!VlMnKJ+S@puvpA*L;r3_T7hHZRx+a$jf?w?#IgCK2@$m>t_Vu*QPIl!TV6?>#&uDMAxKVwb<t&LfrD1Ap95FoQHwR6BEB;`U{#TKuMcp6GEil(YooS-CAMyYyHJzO4)0dv`QBhn>G=biQUcXx~$;0}PAtFPrqGQC=8Z*>K*|`|-jiPg0!${i4!OKWF!<<!-wXX9%jod3_cebp$kx3WA_S8NGHW&xxXx}z79VXU49TcS$D7RN)#{TA9KlNu!Mz7kJJ>#L7s+O`X%5K)w_*oyC^RM$Nyx;Il&6xb-G=dB5ehl%vOC%g3tw-*FJM^qh;H<l}6(Btj;zx>U<3ie%bhg|M0Smi>h+~?E>8v@!9rLaEwzSGt%RBpYK~=r7vNF`ERX1eYY^Qu9$v6mD!WwG)1d^3mqK9VT@B9igdXpUOjC{$F$_qKxi&9%X){7$zT%vo+sCR0KviTb2fKdE$HkC(!5h9kUXWro+uI@8T)6wTQzBqw=<@}HFF?Nlk;=T|snrfXoZEmr0sDIbZ;XUaA0vwduMbpM76$KBo<VGFs6+)YeW@D7#GaDN`t!0WOC3wz>f%+>>mDSF_mp1#X`v%W2X0BS21I`_hy{*<p%IQ}M+DN9924rI>s}*cVmK2mNL%NTGD>}2AT-@g^Y!3{zQd*RuB6nSNos!~0&3I2g`l(<FWWAPuD`rwxHJf|x%1n7knDPv3WV#)fQ__dsR<odM`wS1{$iy_Cg-_A1IQ;>jPi1EWB*e$+s&!X)@rWb(Q`Q+}4#8HNNpPmqoKn9|9*321ME}mtvn9byS7I0kd{hoAJD2jirg|WhNS~9a_ALmd@r`iPdwY&V1TwKNCh3JqUC#{WO2OoU@tgc?;N)T`o<}Vo0cEzTr*2+F1yMFi>-e)gJARor$Ds{#ynrH#ILf*NLJ9R+MfcH#$<amWT}HZ@ejD*4xTq7_4{%--v_I4GbL&w%Rd!gsaet{a!7-Yj2XvP{PXOPjqSK>OQVY#1^p-!~Hp-5-cdO~$b!~d9EeSnOy-N}u<HQG!=*Og<L7j!;kzI{;Plh=2I@vy-<e(sqhG@Deg6m;?_t_3#4r+pAu%|*R{DWQ>O=o~$*d>c*f+95M+2a(l)U@*vMhd~i=JD*=;_Rl@%nXDm>c)$fs9ax|ogWE$>g`I=ds1g@O^#;H_^g>y`Y%}~PffRjPX+w__NLd9-5o`g!)50IIB1Er!R_BUPx#$`y)*`~2R)P*PG_xtx}46QC7UZ*&xi7f?M;%na_)5XD=xOBY#YV%?IGDOWldOcE^mog{Y#17M@EK&VY2fThyNWDEgY?`uc&w75pQ`yT=NcZ8*$2HZjS!duQP@$HM?nmmHn?NdVw;9HAA;7&MuZH)0vzJsfGV^C$gOgc$m(t&K<j-Mk1asKsw=YxY!-!dWFajcX(uURBNf|e(C56iN#0%BwTNn-iveghGX8DX{?b?R}rg=L++@ba{s1BWQ|tVv#vjyh3RxY`zhH@V_M>m{~zxIVS94?UBqGf^zMxsKgKFBGm)d~6I`n$&XCU1&HDJ*2nmKQvrVj}M=4-4?o;jW)jd9H2gM2>ODMS<+<uFMIMwc>nTGjn-4xHohsF03ol%s&+RjQjeH6QLj&U-NSkf;NPbwa>+eGrxcouM{GCt<swl6W<q><@c;|c%K@ECNqfQ$Sz*z_D;jqG<&#BFN9O?3wK<v$-4%?k0ywZN{L$!cwxJyJU1N*aHI$zvSm79b}cnox!whj=w{4t&-6wFueX<GBCHe>2Y71M1)7WFx16t=0x2SLWUV$`H?#q~18kP&@Gm^pH_dDjfEf<QPv14?g0f9|`)I!SQ3cLB#vW@emn&TaMsxeZ!n1?1hk5gzwazAU>8gDIv;y>@|w~7@bt)!zz!?tiILL2;=%k=Ll8Px#_W5>`f}~=*s2j5$dclO`MDSSi8kpQRA*i47Y{jYEUM>ka?Cy_oBNxdi86-obA=fA$$KNIATEj9>wN@Bgz5wV8EJtOkeepW<F{V!BOT4t@@z~?qO(G#6-`vt7VsvuC==MFG@(bheE;n&&sU&`UOMITuvPcNSW6pTGfZd%`KMu2g|{w>qkUc+-To@ND%<gyWXeC2Ke@&&jVRmJBNPO;1kDd_N`@p?1<s!D=x47DU#hL%G3dO+vsM-T=jm>d7Z8&=^<LWAr!n(b{<lhrPb<)ZP=(Qf~!-BXD4SX_BL==i7$*aKE_K&1a`Vt5N|Z0OBOP^)w3N=jH~f%?{ss-sm^ry&%5<!yZYG#Wyc{Hunn>98FoB(+pNsudtOHCdOQdSaLc`X=0PI`=N2>w;08t=DyFcw#hi~YXX#r$<L4$ezdMeuJZ8*6$~z<1Xgm6!dgI>r3r4S_SP33}f%V>>=?Y2A<=2nJPW;|K?YRE!BW{oV)Ff>@9qe|!P3fUY+ISi{lS(R!!BIjhdZH8i4}Kl^#mcdDo&BK^uTs{lZTW{}WCwWfVE$&6+gv$tW7))yXdcY4_%-reIxsVMi;}XGuhsIvN^4DKOF7TKAF75s0=9zNzq^j8C{4Qkhv9zH<w4c}O8YgW=REY_+Ne@uQMGgz(r0e3G(88NdkEAOHSpaY>#s3=o_Q;s_aOSebK?M;VtZ)c^;GBho9;%<;&>N7^r&A;X!9{tZtiMkdVK=8Uy=fk!nL&H&}j;)IUMgXaCY{xis}Q`63Ff&l5n>meq}^|5>kr&;DnvzE^&sL&WL2@?9URrYinj|)8pT9SND6dwq}1he4G^$+z%tBBwUszR$lG;(8||vZO4F+_%*B^d`S<-nXMN^dwV9K^N@-=_WG7P;Cd<USYQ}(vh^J07qx0A)TB<*8PUyzPl%G@;sRs%cBrLj&E48<U%ALfPdNueUTU5C9IM2YFij63$2+E^cR0bUfb?F+G_GL_<-NUVx5}P0Xm0S)V)OU*^DsnPYjPh@cLpG*HjA1HZkY1a<xZ;pO_VG)f*O_b_A!*3!=OLdCcLf8)ghRhJ7X6IV6HG&%r02!dF~r?%GP^j#a_X|fyhf1G(n{n%iJw+jFk<4NhjxxP0>SU-$tpDl>-<{yji)+i7u3ao%!Y5E+=}2Ot@1V1@Vz&D?|5}G|Fb2Gk_mt3%VPf2&#v#oMl6Dj3yN$fT)&B)bY}@adY)vpLm|??&i0;b~Z4(L0}wy9J<&AvvW^<#E(uJ&Lx)17C9sbNA_b*Amg<9vHPSs3EHYY?7C9qeo<G%9jj0Eq@V&<nO1x3#NN3l{C%{lr=z5qKb9ib$|+S3Q<~1*z)EWp`n3Ca8`+s0y&mYN-kR-Wp#?sq`RSf7r5)X39I_20aIku}k5A72lUKKkW1-wh*yLi<nP_}vZ^mER&&{f7ptt+_IhT8nYER2MQ@0WAjj|^#S{ulO`;Dol1!p@L%4H8P9mFgUq)#mwPDEBa7X!;4?M@kuvlZr=mB}=olRnni3v1nbG9B9py2(B_=92VUVJ<(2rw1=`p~l3P(|yDZF<Fk@$&^owkL86mm1ZKYwlmX+tHi5`qGer0%S7oy&!@1NTPOKj^Aj%}Dw|f)M;}-oQSOO><$0pe@<j(+OkX(qBWpwCw4$h&k8)?}N1F_{R;E~8W;EUEuUBb4b&3?N9{mWJ`WlS&V^m$NoK&d^KG(!&EuNqI(_G~!(tZ$D)^$E|Oi8NpLhYk`Y^~&&s@Q)Kj^ILCbLwMTi>ppE{9u<)eQ(dc%*MDBM5^G~O!iTH;*bC_xnxU6IIgxOJ?d%h-&2Y1&RVp4*8;rg56RtJo1Xh`$x)E9J;mYGVi{BW2sqi-8P8bowLQsq&yn$cY&x~Mepe25Xu0?Ns((H^llJC!M@ZAIh&_r>hmdl&s&CI;BMvs0Chmav*hPik{FHD_UE%iGokRY+-}nmq&mX%u8SCo=9HJ;L+maJ5B3JDA0@P-r;L~MIRTysN!9|R@D6HuroF$r=A2NlgoHMSc+~dm+86p+~$r@QGkKMS2#HR50ZfiJsCa_d)NtN5iEPNC<Sb}&+uorcBm?qVAS}epZ>_6WZJ|2Oj^YK>%H+LTVSOV7{I}bQJzc$yrA)I`n&e`56)8pjZfbD)1c@VhhO)(s-skYhS-EwnhZx5mAXB;=a)0!IeXfN8U4;anl@sa*w3+RWMr_etAcoOI6E4MMkq1*qg#gA>);m-g43}sgF6Tusk?0$d{u($i+OL!nu?rMh5o<2F{s)y}qo*AlL{KS{Z$<<SKhH4i-nT6;dla_GmQcrsQMvAgukSXu0d+S4XCv!|V9GqQQbsDITHQi3<m>Qn98v@iXB6Gy`gTZ3aVm6L;D6;G~NI>)~(KN!NLG5^UN+6wz;61M)Pz)49`9;{o&Nw2vjKfp!^1kCCkKhB}!hVhBV3f3$`Wl_whU1YqO41r#ck9uD9315gie$cfZjM;;qIxb<_}UtbuU@Mz%9a@Y&T%iMk8Jmq^X6fjseTP?u^Rl)n^X6A?aThjKRG`-_@YDVv#0+o%${31wZ4!N_@t-Amf4FTy5Khp?ZvcE818A<U7H@yvOLERN1ez^)Y!-h3B%bMe=Ev^Xs0z{<!4czas8Ze5MCtnq?r1gY9Xm>Dnm})<JiwJWEgL3()tYJ`(LI}^vH_CKEb%SnoqB&%fV#*jAL9!slSHt+?iUmM5^JohL1uD+}sr#-}E!7);T9!9=mQ#c6AimEIrZ!cA6=(-@)zc+hw)AzL27wpsVjG^qOValS3t2^;^j9Kyq~;Ujv%-vB==}5_jgL`WAnch*JCD<%BOJWjF+j{@^VoNg1;N32Se^){_!@Xmr^#tJQ^t8_!PNbB^9;3bgszOd$W<K`1*)IGwZnqH+pc=zDCq8jB~<&zz?<yvKxHd2(E`ezv&IS!Yl^Ah-ecwG_dXly1fJj*<`}1v>|l?R0=^pSGWm{%yzQY)GPbLJwOa+0~1z!CC6s_xwoUZYdrcr-m+k299BR&8ted=I;$<<bc&SnBvLel(gYPrI@!vp2Q{0fAK_2T;0SDN0qE*-(zpCN9i66vIBbN*uqCv2+#aO)y9PH?TyBdvEPNWtnRAQonqW5%1~FXiHac)iyxz9@k!Rs;5NK_oBhBCL<i^3nl5yGY%${~hOv|N&-vs(<s<uWr+cAlreM<#p;`>?sF-8iRP_NnyDV>mQfG~KW?fJJZG(*`=W)&!tDK$Go;#QHj4C$#MV;ORzg-=RSJj8<9DdH;UO0jpx_3_n=6D&+HoI2{pWfyvANgmELhALb)8#~kdE?wjoXNg5J{K;8&)P)-0CKZmC3ze^7aS4q9G=y^#a1e~J_f##qRaF>rR08u?;g_ZOcvhmV;&>*C#m$e)&S7&^Y{NYF}mw5DZKkD|5*)|>F#2ih|-v{Yt<F#Ig|0gE&T+rA@9)+cm_jE5LweT&GZr)3bXZ`YaH^_9*ZpQ!+D~pL|`1EOV_n9#V~v-Z8N{^`zfuquP7>~ui5qNl}+Njlr25wN@hu6nG{Q3s9H-`=jB9EnQ0Ld$7M%RWF4dGd^|^zwGX*?E|2N(Z#_PqRvR+^$~N4OhG%0Ycf90z;dgo7EE~9-8<o)jAeW8eqge^WAMME;T|9LD5Z4$#<{`5!{9JzK+(Oo29I)2*p`&76VbqU#2<*#_QYg=z*WLF^9iLAnXu0)3^_d>!hL;}d#}2x%mxMhgupPU^S&U7~=P4Jc63*z}f|G<yUfI*5XC4p{9xbdVtY-_*dsKA!JECK|?=dr=r^j>CyUsrSV~;q4%#dk$EP`RV89atb6Q32(?uqEy&gGYM%B<)u>W*$R=C;%2<rz<z+$1(TK|f|uQng}wmov9QNW~sS`K}p#7ZS&EwO}NaJvz<nyIFpYV^~F_XRYx}{vLA+>qj$R_(-VYPWts2Z7!jHG}HwSPBJ|nq-Fb9*wgT&UHLT4BH1JF1Z=UMhtMMI5<M^h&RnYlD*TL8P86<Ci1rprIVTU!l=QH!#Kn1fD*+XckHxTi{p)MC?H1kJ=D}$x#(!+kzMJQ3XRSi|hFU@{U#&!s&1`uAz-~<D<m6C`9$pu7(RNP#sgtVbJX2+EvMtATtz9fvLIXUihvs!8b++fX^L(#aE7hAUYZW8tJr13OE9uI_T80%bVQsi(+c=|brBvPI0HZ2;APc{apK#3rAHuBam&VfXd)XQr_oBC1CR)men2zGSuLe|ZyYxL_UQjX@#mi?{>enJS?kBg0=E>`t%h&voz^(GRz8Jv4)h%bZYVLtayjy&4e-Z5pIZvM*nct&{*hN*&Z719?0$jV35Pyy?H?0p`e=AY%`UtB?HNR-0II@<<_$DsH_S2{~tvkJTOw*MQP|e&htw#%U-;-WKngHXyiK5RL6h5dZOG1{sr`y`>&>L#HZLIJmrkljckKdcNuAtXO({#w%(pP_onVG~cvg|fj9%@(0q1z`-`d`O8EHtw|la&in+Es~)4n`{%J-06s<`SJf&LLrOhf1>*tLwhtPIaYb(wxOmbpDNUv2d&Ef0mjkQgD;63Vl|LE=I!PowM1u;uCzPPR@8)XZnlx_|(o-E+^LOP~(&@ij@j1YID1xjEyV}eT@W!yiTthbL}fk9J6p+$fDF|r2@4GMY||=Z|Z(xO3l_ex(-R2FNd2sHtyW|7#x#xmHX-wQQ=yc^gsXe{{R9idX4')))
RIVER_RANGE = random.Random(741041).sample([(pair, 1) for pair in combinations(CARD.values(), 2)], 384)

def river_actions(history):
    for event in reversed(history):
        if event.kind == "board":
            break
        yield event


def priced_river_share(state, me, foe, cost, price, pot_bb):
    hold = [CARD[x] for x in state.cards]
    strength = []
    types = []
    for board in state.variant["boards"]:
        public = [CARD[x] for x in board]
        strength.append(eval7.py_hand_vs_range_exact(hold, RIVER_RANGE, public))
        types.append(eval7.evaluate(hold + public) >> 24)
    aggression = [0, 0, 0]
    street = 0
    raised = checked = 0
    for event in state.history:
        if event.kind == "board" and event.amount == 1:
            street += 1
        elif event.kind == "raise":
            if street < 3 and event.seat == foe.seat:
                aggression[street] = 1
            if street == 3 and event.seat == me.seat:
                raised = 1
        elif street == 3 and event.kind == "check" and event.seat == me.seat:
            checked = 1
    features = [min(strength), max(strength), price, cost/max(1,me.stack),
                log1p(pot_bb), *aggression, raised, checked, min(types), max(types)]
    estimate = RIVER_BASE
    for tree in RIVER_TREES:
        node = tree[0]
        while not node[5]:
            node = tree[node[2] if features[node[0]] <= node[1] else node[3]]
        estimate += node[4]
    return estimate




def track_preflop_responses(state, memory):
    # One flag byte, a two-byte acted mask, then counts of opportunities and folds.
    # The event stream resumes at the last decision, including the preceding action.
    seats = len(state.seats)
    data = bytearray(memory) if len(memory) == 3 + 2 * seats else bytearray(3 + 2 * seats)
    mode = data[0]
    acted = data[1] | (data[2] << 8)
    for event in state.events:
        kind = event.kind
        if kind == "hand":
            mode, acted = 1, 0
        elif kind == "board":
            mode = 0
        elif mode and kind in ("fold", "call", "raise", "check"):
            seat = event.seat
            bit = 1 << seat
            if mode == 2 and not acted & bit:
                offset = 3 + 2 * seat
                if data[offset] == 255:
                    data[offset] //= 2
                    data[offset + 1] //= 2
                data[offset] += 1
                data[offset + 1] += kind == "fold"
            acted |= bit
            if kind == "raise":
                mode = 2
    data[0], data[1], data[2] = mode, acted & 255, acted >> 8
    return bytes(data)


class Agent(BaseAgent):
    def act(self, state, memory):
        memory = track_preflop_responses(state, memory)
        return self.choose(state, memory), memory

    def choose(self, state, memory):
        me = next(s for s in state.seats if s.seat == state.seat)
        foes = [s for s in state.seats if s.seat != me.seat and s.status in ("active", "all_in")]
        opponents = max(1, len(foes))
        bb = max(1, state.blinds.big_blind)
        cost = min(me.stack, state.to_call)
        checking = state.can("check") is not None
        late = state.seat == state.button
        stack_bb = (me.stack + me.bet) / bb
        if state.phase == "discard":
            index, _, _ = board_equities(state, opponents)
            return Action("discard", cards=(index,))
        if not state.board:
            start = preflop_key(state.cards) * 3
            opening_eq = PREFLOP_EQUITIES[start + 1] / 250
            high = max(s.bet for s in state.seats)
            count = state.players_remaining
            button = state.seat == state.button
            big_blind = any(e.kind == "blind" and e.seat == me.seat and e.amount == bb for e in state.history)
            late_position = button or (not me.bet and opponents <= 3)
            short = stack_bb < 11
            if (count >= 4 and opponents == 1 and high >= 7 * bb
                    and cost and cost < 0.25 * me.stack and opening_eq < 0.60
                    and min(me.bet + me.stack, foes[0].bet + foes[0].stack) >= 40 * bb):
                # Deep in a re-raised pot, marginal opens struggled to realize their equity.
                previous_raises = [e.seat for e in state.history if e.kind == "raise"]
                if previous_raises == [me.seat, foes[0].seat] and foes[0].stack > 0:
                    return Action.fold()
            if cost and high > bb and (cost >= 0.40 * me.stack or high >= 8 * bb):
                return facing_large_raise(state, me, cost, bb, foes, high)
            if high <= bb:
                threshold = 0.457
                if count <= 2:
                    threshold = 0.314 if button else 0.405
                elif late_position:
                    threshold = 0.398
                elif count <= 4:
                    threshold = 0.415
                limpers = sum(e.kind == "call" for e in state.history)
                if limpers:
                    threshold += min(0.045, limpers * 0.015)
                if big_blind and checking:
                    threshold = max(threshold, 0.475)
                if short and not limpers:
                    threshold -= 0.025
                if (count >= 3 and opponents == 1 and not big_blind and me.bet > 0
                        and foes[0].bet == bb and me.bet < bb and not limpers
                        and min(me.stack, foes[0].stack) >= 12 * bb
                        and opening_eq < threshold - 0.035):
                    # Frequent prior folds to an opening raise identify overfolding blinds.
                    offset = 3 + 2 * foes[0].seat
                    if 10 * (3 + memory[offset + 1]) >= 7 * (5 + memory[offset]):
                        return raise_sized(state, 2.6 * bb)
                if opening_eq >= threshold:
                    size = me.bet + me.stack if short else (2.6 + 0.9 * limpers) * bb
                    return raise_sized(state, size)
                if checking:
                    return Action.check()
                if me.bet > 0 and cost <= 0.5*bb and opening_eq >= threshold-0.035:
                    return Action.call()
                return Action.fold()
            if checking:
                return Action.check()
            raises = sum(e.kind == "raise" for e in state.history)
            # The practice field charged our weakest cold calls heavily. A second
            # raise, players behind us, and high prices each narrow our range.
            repop = 0.585 if count > 3 else 0.550
            if raises <= 1 and opening_eq >= repop:
                size = me.bet + me.stack if stack_bb < 16 else high * (3.2 if not button else 2.8)
                return raise_sized(state, size)
            price = cost / (eligible_pot(state, me) + cost)
            floor = 0.485 if count > 3 else 0.452
            if button:
                floor -= 0.012
            if big_blind and raises == 1:
                floor -= 0.042 if high <= 3.2 * bb else 0.014
            if count == 2:
                floor -= 0.048
            if raises >= 2:
                floor += 0.055
            floor += max(0.0, price-0.30)*0.35
            return (Action.call() if opening_eq >= floor else Action.fold())

        _, share, weaker_side = board_equities(state, opponents)
        if opponents > 2:
            share *= 1 / (1 + 0.09 * (opponents - 2))
        pot = eligible_pot(state, me)
        price = cost / (pot + cost)
        risk = 0.045 + 0.058 * (cost / max(1, me.stack))
        payouts = state.config.payouts
        paid = sum(p > 0 for p in payouts)
        if state.players_remaining == paid + 1 and cost > me.stack * 0.35:
            risk += 0.06
        # A sizeable first river bet represents a much stronger range than
        # the unconditioned random holdings in board_equities.
        street = len(state.board)
        if cost and (street in (3, 4) and price >= 0.18 or street == 5 and opponents == 1 and price >= 0.29):
            we_raised = False
            for event in reversed(state.history):
                if event.kind == "board":
                    break
                if event.kind == "raise" and event.seat == state.seat:
                    we_raised = True
                    break
            if not we_raised:
                if street == 5:
                    risk += 0.18
                elif opponents == 1:
                    risk += 0.18 if price >= 0.29 else 0.14
                else:
                    risk += 0.12
        value_cut = (0.65 if opponents == 1 else 0.55) + (0.07 if cost else 0)
        can_steal = checking and late and opponents == 1 and share > 0.47 and len(state.board) < 5
        if (street == 3 and checking and not late and opponents == 1 and share > 0.47
                and foes[0].status == "active" and min(me.stack, foes[0].stack) >= .72 * pot
                and state.history and state.history[-1].kind == "check"):
            can_steal = True
        if share >= value_cut or can_steal:
            fraction = 0.72 if share > 0.79 and weaker_side > 0.38 else 0.48
            target = me.bet + cost + fraction * (pot + cost)
            return raise_sized(state, target)
        if checking:
            return Action.check()
        if share < price + risk:
            return Action.fold()
        if street == 5 and opponents == 1 and not any(
                e.kind == "raise" and e.seat == me.seat for e in river_actions(state.history)):
            estimated = priced_river_share(state, me, foes[0], cost, price, pot/bb)
            if estimated < price - 0.025:
                return Action.fold()
        return Action.call()
